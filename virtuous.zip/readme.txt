=== Virtuous ===
Contributors: stevorevo
Tags: virtuous, non-profits, donor relationship management
Author URI: http://virtuoussoftware.com
Requires at least: 4.5.0
Tested up to: 4.5.3
Stable tag: trunk
Version: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
Virtuous is a plugin that connects a website to your Virtuous DRM account, providing the ability to display projects and redirect to a donation page.

== Installation ==
Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.
Use Virtuous->API Settings to connect to your Virtuous Account
Use Virtuous->Project Settings to select the projects to display on your page and configure Giving Fuel