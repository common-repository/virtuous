var $ = jQuery.noConflict();

function redirect_to_giving_fuel(redirect_url, project_id, update_status) {

	var $ = jQuery.noConflict();

	if (update_status == 'true') {
		var data = {
		    action: 'update_project_status',
		    project_id: project_id
		};
		$.post({
			url: virtuous_ajax_script.ajaxurl,
			data: data,
			success: function( response ) {
				console.log(response );
			},
			error: function( response ) {
				console.log( response );
			}
		});		
	}
	
	window.location.href = redirect_url;
}
